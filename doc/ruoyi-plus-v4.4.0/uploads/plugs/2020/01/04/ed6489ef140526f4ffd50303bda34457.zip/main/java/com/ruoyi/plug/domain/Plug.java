package com.ruoyi.plug.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 插件管理对象 plug_plug
 * 
 * @author markbro
 * @date 2020-01-04
 */
public class Plug extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 插件ID */
    private Long plugId;

    /** 插件分类 */
    private Long categoryId;

    /** 插件名称 */
    @Excel(name = "插件名称")
    private String plugName;

    /** 介绍 */
    @Excel(name = "介绍")
    private String description;

    /** 封面图片 */
    @Excel(name = "封面图片")
    private String coverImg;

    /** 详情图片 */
    @Excel(name = "详情图片")
    private String detailImg;

    /** 收费类型 */
    @Excel(name = "收费类型")
    private Integer payType;

    /** 支付费用 */
    private Long payCount;

    /** 显示支付费用 */
    @Excel(name = "显示支付费用")
    private String payShow;

    /** 作者用户ID */
    private String authorId;

    /** 作者 */
    @Excel(name = "作者")
    private String authorName;

    /** QQ */
    private String authorQq;

    /** 作者微信号 */
    private String authorWx;

    /** 作者微信二维码 */
    private String authorWxQrcode;

    /** 版本号 */
    @Excel(name = "版本号")
    private String version;

    /** 审核状态 */
    @Excel(name = "审核状态")
    private Integer auditState;

    /** 插件状态 */
    @Excel(name = "插件状态")
    private Integer status;

    /** 下载次数 */
    @Excel(name = "下载次数")
    private Long downloadTimes;

    /** 点赞数 */
    @Excel(name = "点赞数")
    private Long likeTimes;

    /** 详细信息 */
    private String content;

    /** 压缩包 */
    private String zipPath;

    /** 插件标志 */
    private String plugFlag;

    public void setPlugId(Long plugId) 
    {
        this.plugId = plugId;
    }

    public Long getPlugId() 
    {
        return plugId;
    }
    public void setCategoryId(Long categoryId) 
    {
        this.categoryId = categoryId;
    }

    public Long getCategoryId() 
    {
        return categoryId;
    }
    public void setPlugName(String plugName) 
    {
        this.plugName = plugName;
    }

    public String getPlugName() 
    {
        return plugName;
    }
    public void setDescription(String description) 
    {
        this.description = description;
    }

    public String getDescription() 
    {
        return description;
    }
    public void setCoverImg(String coverImg) 
    {
        this.coverImg = coverImg;
    }

    public String getCoverImg() 
    {
        return coverImg;
    }
    public void setDetailImg(String detailImg) 
    {
        this.detailImg = detailImg;
    }

    public String getDetailImg() 
    {
        return detailImg;
    }
    public void setPayType(Integer payType) 
    {
        this.payType = payType;
    }

    public Integer getPayType() 
    {
        return payType;
    }
    public void setPayCount(Long payCount) 
    {
        this.payCount = payCount;
    }

    public Long getPayCount() 
    {
        return payCount;
    }
    public void setPayShow(String payShow) 
    {
        this.payShow = payShow;
    }

    public String getPayShow() 
    {
        return payShow;
    }
    public void setAuthorId(String authorId) 
    {
        this.authorId = authorId;
    }

    public String getAuthorId() 
    {
        return authorId;
    }
    public void setAuthorName(String authorName) 
    {
        this.authorName = authorName;
    }

    public String getAuthorName() 
    {
        return authorName;
    }
    public void setAuthorQq(String authorQq) 
    {
        this.authorQq = authorQq;
    }

    public String getAuthorQq() 
    {
        return authorQq;
    }
    public void setAuthorWx(String authorWx) 
    {
        this.authorWx = authorWx;
    }

    public String getAuthorWx() 
    {
        return authorWx;
    }
    public void setAuthorWxQrcode(String authorWxQrcode) 
    {
        this.authorWxQrcode = authorWxQrcode;
    }

    public String getAuthorWxQrcode() 
    {
        return authorWxQrcode;
    }
    public void setVersion(String version) 
    {
        this.version = version;
    }

    public String getVersion() 
    {
        return version;
    }
    public void setAuditState(Integer auditState) 
    {
        this.auditState = auditState;
    }

    public Integer getAuditState() 
    {
        return auditState;
    }
    public void setStatus(Integer status) 
    {
        this.status = status;
    }

    public Integer getStatus() 
    {
        return status;
    }
    public void setDownloadTimes(Long downloadTimes) 
    {
        this.downloadTimes = downloadTimes;
    }

    public Long getDownloadTimes() 
    {
        return downloadTimes;
    }
    public void setLikeTimes(Long likeTimes) 
    {
        this.likeTimes = likeTimes;
    }

    public Long getLikeTimes() 
    {
        return likeTimes;
    }
    public void setContent(String content) 
    {
        this.content = content;
    }

    public String getContent() 
    {
        return content;
    }
    public void setZipPath(String zipPath) 
    {
        this.zipPath = zipPath;
    }

    public String getZipPath() 
    {
        return zipPath;
    }
    public void setPlugFlag(String plugFlag) 
    {
        this.plugFlag = plugFlag;
    }

    public String getPlugFlag() 
    {
        return plugFlag;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("plugId", getPlugId())
            .append("categoryId", getCategoryId())
            .append("plugName", getPlugName())
            .append("description", getDescription())
            .append("coverImg", getCoverImg())
            .append("detailImg", getDetailImg())
            .append("payType", getPayType())
            .append("payCount", getPayCount())
            .append("payShow", getPayShow())
            .append("authorId", getAuthorId())
            .append("authorName", getAuthorName())
            .append("authorQq", getAuthorQq())
            .append("authorWx", getAuthorWx())
            .append("authorWxQrcode", getAuthorWxQrcode())
            .append("version", getVersion())
            .append("auditState", getAuditState())
            .append("status", getStatus())
            .append("downloadTimes", getDownloadTimes())
            .append("likeTimes", getLikeTimes())
            .append("content", getContent())
            .append("zipPath", getZipPath())
            .append("plugFlag", getPlugFlag())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
