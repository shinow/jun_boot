package com.ruoyi.plug.mapper;

import com.ruoyi.plug.domain.Plug;
import java.util.List;

/**
 * 插件管理Mapper接口
 * 
 * @author markbro
 * @date 2020-01-04
 */
public interface PlugMapper 
{
    /**
     * 查询插件管理
     * 
     * @param plugId 插件管理ID
     * @return 插件管理
     */
    public Plug selectPlugById(Long plugId);

    /**
     * 查询插件管理列表
     * 
     * @param plug 插件管理
     * @return 插件管理集合
     */
    public List<Plug> selectPlugList(Plug plug);

    /**
     * 新增插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    public int insertPlug(Plug plug);

    /**
     * 修改插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    public int updatePlug(Plug plug);

    /**
     * 删除插件管理
     * 
     * @param plugId 插件管理ID
     * @return 结果
     */
    public int deletePlugById(Long plugId);

    /**
     * 批量删除插件管理
     * 
     * @param plugIds 需要删除的数据ID
     * @return 结果
     */
    public int deletePlugByIds(String[] plugIds);
}
