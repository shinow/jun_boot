package com.ruoyi.plug.service;

import com.ruoyi.plug.domain.Plug;
import java.util.List;

/**
 * 插件管理Service接口
 * 
 * @author markbro
 * @date 2020-01-04
 */
public interface IPlugService 
{
    /**
     * 查询插件管理
     * 
     * @param plugId 插件管理ID
     * @return 插件管理
     */
    public Plug selectPlugById(Long plugId);

    /**
     * 查询插件管理列表
     * 
     * @param plug 插件管理
     * @return 插件管理集合
     */
    public List<Plug> selectPlugList(Plug plug);

    /**
     * 新增插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    public int insertPlug(Plug plug);

    /**
     * 修改插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    public int updatePlug(Plug plug);

    /**
     * 批量删除插件管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deletePlugByIds(String ids);

    /**
     * 删除插件管理信息
     * 
     * @param plugId 插件管理ID
     * @return 结果
     */
    public int deletePlugById(Long plugId);
}
