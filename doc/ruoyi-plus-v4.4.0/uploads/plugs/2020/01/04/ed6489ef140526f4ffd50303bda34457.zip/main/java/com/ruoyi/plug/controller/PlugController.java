package com.ruoyi.web.controller.plug;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.plug.domain.Plug;
import com.ruoyi.plug.service.IPlugService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 插件管理Controller
 * 
 * @author markbro
 * @date 2020-01-04
 */
@Controller
@RequestMapping("/plug/plug")
public class PlugController extends BaseController
{
    private String prefix = "plug/plug";

    @Autowired
    private IPlugService plugService;

    @RequiresPermissions("plug:plug:view")
    @GetMapping()
    public String plug()
    {
        return prefix + "/plug";
    }

    /**
     * 查询插件管理列表
     */
    @RequiresPermissions("plug:plug:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Plug plug)
    {
        startPage();
        List<Plug> list = plugService.selectPlugList(plug);
        return getDataTable(list);
    }

    /**
     * 导出插件管理列表
     */
    @RequiresPermissions("plug:plug:export")
    @Log(title = "插件管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Plug plug)
    {
        List<Plug> list = plugService.selectPlugList(plug);
        ExcelUtil<Plug> util = new ExcelUtil<Plug>(Plug.class);
        return util.exportExcel(list, "plug");
    }

    /**
     * 新增插件管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存插件管理
     */
    @RequiresPermissions("plug:plug:add")
    @Log(title = "插件管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Plug plug)
    {
        return toAjax(plugService.insertPlug(plug));
    }

    /**
     * 修改插件管理
     */
    @GetMapping("/edit/{plugId}")
    public String edit(@PathVariable("plugId") Long plugId, ModelMap mmap)
    {
        Plug plug = plugService.selectPlugById(plugId);
        mmap.put("plug", plug);
        return prefix + "/edit";
    }

    /**
     * 修改保存插件管理
     */
    @RequiresPermissions("plug:plug:edit")
    @Log(title = "插件管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Plug plug)
    {
        return toAjax(plugService.updatePlug(plug));
    }

    /**
     * 删除插件管理
     */
    @RequiresPermissions("plug:plug:remove")
    @Log(title = "插件管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(plugService.deletePlugByIds(ids));
    }
}
