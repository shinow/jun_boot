package com.ruoyi.plug.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.plug.mapper.PlugMapper;
import com.ruoyi.plug.domain.Plug;
import com.ruoyi.plug.service.IPlugService;
import com.ruoyi.common.core.text.Convert;

/**
 * 插件管理Service业务层处理
 * 
 * @author markbro
 * @date 2020-01-04
 */
@Service
public class PlugServiceImpl implements IPlugService 
{
    @Autowired
    private PlugMapper plugMapper;

    /**
     * 查询插件管理
     * 
     * @param plugId 插件管理ID
     * @return 插件管理
     */
    @Override
    public Plug selectPlugById(Long plugId)
    {
        return plugMapper.selectPlugById(plugId);
    }

    /**
     * 查询插件管理列表
     * 
     * @param plug 插件管理
     * @return 插件管理
     */
    @Override
    public List<Plug> selectPlugList(Plug plug)
    {
        return plugMapper.selectPlugList(plug);
    }

    /**
     * 新增插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    @Override
    public int insertPlug(Plug plug)
    {
        plug.setCreateTime(DateUtils.getNowDate());
        return plugMapper.insertPlug(plug);
    }

    /**
     * 修改插件管理
     * 
     * @param plug 插件管理
     * @return 结果
     */
    @Override
    public int updatePlug(Plug plug)
    {
        plug.setUpdateTime(DateUtils.getNowDate());
        return plugMapper.updatePlug(plug);
    }

    /**
     * 删除插件管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deletePlugByIds(String ids)
    {
        return plugMapper.deletePlugByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除插件管理信息
     * 
     * @param plugId 插件管理ID
     * @return 结果
     */
    @Override
    public int deletePlugById(Long plugId)
    {
        return plugMapper.deletePlugById(plugId);
    }
}
