package com.ruoyi.common.constant;

public interface ShiroRedisConstants
{
    public static final String DEFAULT_SESSION_KEY_PREFIX = "shiro:redisCache:sessionId:";

    public String keyPrefix = DEFAULT_SESSION_KEY_PREFIX;
}
